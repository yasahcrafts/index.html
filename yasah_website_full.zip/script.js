
function order(product){
let number = "91XXXXXXXXXX";
let message = "Hello, I want to order: " + product;
let url = "https://wa.me/" + number + "?text=" + encodeURIComponent(message);
window.open(url);
}
